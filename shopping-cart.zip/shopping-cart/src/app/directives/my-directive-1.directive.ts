import { Directive,ElementRef } from '@angular/core';

@Directive({
  selector: 'appMyDirective1'
})
export class MyDirective1Directive {

  constructor(private elementRef: ElementRef) {
    elementRef.nativeElement.innerHTML = `<div>helloooooooo i am the directives</div>
     <div>
  <input type="radio" name="colors" (click)="color='lightgreen'">Green
  <input type="radio" name="colors" (click)="color='yellow'">Yellow
  <input type="radio" name="colors" (click)="color='cyan'">Cyan
</div>
    `
   }

}
