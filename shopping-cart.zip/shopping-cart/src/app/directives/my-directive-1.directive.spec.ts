import { MyDirective1Directive } from './my-directive-1.directive';

describe('MyDirective1Directive', () => {
  it('should create an instance', () => {
    const directive = new MyDirective1Directive();
    expect(directive).toBeTruthy();
  });
});
