import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { Router, RouterModule, Routes, ActivatedRoute } from '@angular/router';
import { Product3Component } from '../product3/product3.component';

import { ChangeDetectorRef} from '@angular/core'


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit, AfterViewInit {
  myname = 'Ayyappan'
  myvalue: any
  

  childcmp:any;

  productOwner = 'AXZ Company'

  myCallbackFunction() {

    console.log("Function coming from parent component")
  }

  constructor(private router: Router, private cd : ChangeDetectorRef) {
  }

  @ViewChild(Product3Component) child !: Product3Component;
  ngAfterViewInit(): void {
    this.childcmp = this.child.childData;
    this.cd.detectChanges();
    console.log(this.child.childData)
  }
  public price: any;
  ngOnInit() {
  }

  greet(name1: string) {
    alert("Hello" + name1);
  }
  productDetails() {
    //this.router.navigate(['/', 'users']);
    this.router.navigateByUrl('/ProductDetails');
  }
}
