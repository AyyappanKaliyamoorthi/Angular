import { Component, Input,ViewChild,ElementRef,AfterViewInit} from '@angular/core';

@Component({
  selector: 'app-product3',
  templateUrl: './product3.component.html',
  styleUrls: ['./product3.component.scss']
})
export class Product3Component implements AfterViewInit {
  @ViewChild('highlight') 
  test !:ElementRef;
  ngAfterViewInit(){
    this.test.nativeElement.style.color = "red"
    //this.marker.nativeElement.style.color='red'; 
  }
 

  

  childData = "Data from child component"
  @Input() name:any;

  @Input() componentTitle:any;

  @Input() ameer:any;



  childMethodReceive(){
    console.log("child code work:")
    this.ameer;
    //event.stopPropagation();
   
    
  }

}
