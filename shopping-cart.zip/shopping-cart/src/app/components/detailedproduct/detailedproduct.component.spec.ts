import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DetailedproductComponent } from './detailedproduct.component';

describe('DetailedproductComponent', () => {
  let component: DetailedproductComponent;
  let fixture: ComponentFixture<DetailedproductComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DetailedproductComponent]
    });
    fixture = TestBed.createComponent(DetailedproductComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
