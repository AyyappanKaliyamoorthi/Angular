import { Component } from '@angular/core';

@Component({
  selector: 'app-detailedproduct',
  templateUrl: './detailedproduct.component.html',
  styleUrls: ['./detailedproduct.component.scss']
})
export class DetailedproductComponent {

}
