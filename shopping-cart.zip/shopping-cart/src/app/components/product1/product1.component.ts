import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-product1',
  templateUrl: './product1.component.html',
  styleUrls: ['./product1.component.scss']
})
export class Product1Component {
  @Input() item = '';
  btnText = "Click"
  tst = true;
  myfn(){
   // alert("clicked");
    this.btnText = "clicked"
    
    this.tst = false;
  }
  
}
