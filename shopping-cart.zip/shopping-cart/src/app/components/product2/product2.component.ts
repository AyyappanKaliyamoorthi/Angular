import { Component,EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-product2',
  templateUrl: './product2.component.html',
  styleUrls: ['./product2.component.scss']
})
export class Product2Component {

  @Output() greetEvent = new EventEmitter();
 
  name = "Ayyappan K";

  callParentGreet() {
    this.greetEvent.emit(this.name);
  }

  
}
