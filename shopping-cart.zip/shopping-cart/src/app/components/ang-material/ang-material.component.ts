import { Component } from '@angular/core';

@Component({
  selector: 'app-ang-material',
  templateUrl: './ang-material.component.html',
  styleUrls: ['./ang-material.component.scss']
})
export class AngMaterialComponent {

  sliderValue = 100;

}
