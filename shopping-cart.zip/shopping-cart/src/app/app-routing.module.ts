import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { PagenotfoundComponent } from './components/pagenotfound/pagenotfound.component';
import { Product1Component } from './components/product1/product1.component';
import { DetailedproductComponent } from './components/detailedproduct/detailedproduct.component';
import { AngMaterialComponent } from './components/ang-material/ang-material.component';


const routes: Routes = [
  // { path: '', redirectTo: '/home', pathMatch: 'full' },
  
  {
    path:"home", component:HomeComponent,
    children: [
      {
         path: 'ProductDetails',
         component:DetailedproductComponent
      },
    ]
  },
  {
    path:"Material", component:AngMaterialComponent
  },  
  {
    path: '**', component:PagenotfoundComponent
  },
  
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
